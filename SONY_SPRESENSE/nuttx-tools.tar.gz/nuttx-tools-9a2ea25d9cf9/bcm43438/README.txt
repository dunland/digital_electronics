README
======

These files date from August, 2018.  More recent files may be available at either:

  https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/brcm
  https://github.com/murata-wireless/cyw-fmac-fw

The 43438 is a variant of the 43430.  The calibration file used in the past
is called brcmfmac43430-sdio.AP6212.txt.  The firmware is brcmfmac43430-sdio.bin

